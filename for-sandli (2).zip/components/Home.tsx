import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Heart } from 'lucide-react';
import { BaseProps } from '../types';
import TypingText from './TypingText';

interface HomeProps extends BaseProps {}

// Cast motion components to any to avoid TypeScript errors with missing props
const MotionDiv = motion.div as any;
const MotionP = motion.p as any;
const MotionButton = motion.button as any;

const Home: React.FC<HomeProps> = ({ onNext }) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 text-center relative overflow-hidden min-h-[100dvh]">
      {/* Decorative Background Elements */}
      <MotionDiv 
        animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ repeat: Infinity, duration: 4 }}
        className="absolute top-10 left-10 text-rose-200"
      >
        <Heart size={64} fill="currentColor" />
      </MotionDiv>
      <MotionDiv 
        animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ repeat: Infinity, duration: 5, delay: 1 }}
        className="absolute bottom-20 right-10 text-rose-200"
      >
        <Heart size={96} fill="currentColor" />
      </MotionDiv>

      <MotionDiv
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="z-10 bg-white/60 backdrop-blur-sm p-8 md:p-10 rounded-3xl shadow-xl border border-rose-100 max-w-lg w-full"
      >
        <div className="h-20 md:h-24 mb-6 flex items-center justify-center">
            <TypingText 
                text="Happy Birthday Sandli" 
                className="font-handwriting text-5xl md:text-7xl text-rose-500" 
                speed={100}
            />
        </div>
        
        <MotionP 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 3 }}
            className="text-lg md:text-xl text-stone-600 mb-8 leading-relaxed"
        >
          Today is all about you. I've put together a little journey to show you how much you mean to me.
        </MotionP>
        
        <MotionButton
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 4 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onNext}
          className="group bg-rose-500 hover:bg-rose-600 text-white px-8 py-3 rounded-full font-semibold text-lg flex items-center gap-2 mx-auto transition-all shadow-md"
        >
          Let's Start
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </MotionButton>
      </MotionDiv>
    </div>
  );
};

export default Home;