import React from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, CalendarHeart } from 'lucide-react';
import TypingText from './TypingText';

interface SorryProps {
    onRestart: () => void;
}

// Cast motion components to any to avoid TypeScript errors with missing props
const MotionDiv = motion.div as any;
const MotionP = motion.p as any;

const Sorry: React.FC<SorryProps> = ({ onRestart }) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 bg-[#1a1a2e] text-slate-100 min-h-[100dvh] relative overflow-hidden">
      
      {/* Rain effect background */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        {Array.from({ length: 30 }).map((_, i) => (
            <MotionDiv
                key={i}
                className="absolute bg-indigo-400 w-[1px] h-20"
                initial={{ y: -100, x: Math.random() * window.innerWidth }}
                animate={{ y: window.innerHeight + 100 }}
                transition={{ duration: 0.8 + Math.random(), repeat: Infinity, delay: Math.random() * 2, ease: "linear" }}
            />
        ))}
      </div>

      <MotionDiv 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="max-w-xl text-center z-10"
      >
        <h2 className="text-4xl md:text-6xl font-handwriting mb-8 text-indigo-200">
            <TypingText text="I'm Sorry" speed={150} />
        </h2>
        
        <div className="space-y-6 text-lg text-indigo-200/80 font-light leading-relaxed mb-12">
          <MotionP initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }}>
            For the times I wasn't there when you needed me.
          </MotionP>
          <MotionP initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2 }}>
            For the moments I misunderstood.
          </MotionP>
          <MotionP initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 3 }}>
            For everything that ever made you frown.
          </MotionP>
          <MotionP 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 4 }}
            className="text-white font-medium text-xl pt-4"
          >
            I want to make it right, forever.
          </MotionP>
        </div>

        <MotionDiv 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 5, duration: 1 }}
        >
            <button
                onClick={() => alert("This page is from the past. Let's focus on our future.")} 
                className="border border-indigo-700 text-indigo-300 hover:text-white hover:border-indigo-500 hover:bg-indigo-900/50 px-6 py-3 rounded-full transition-all duration-300 flex items-center justify-center gap-2"
            >
                <CalendarHeart size={18} />
                Last Year Page
            </button>
            
            <button
                onClick={onRestart}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-full transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-indigo-900/50"
            >
                <RefreshCw size={18} />
                See Again
            </button>
        </MotionDiv>
      </MotionDiv>
    </div>
  );
};

export default Sorry;