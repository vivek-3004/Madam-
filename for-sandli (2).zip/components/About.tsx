import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Star } from 'lucide-react';
import { BaseProps } from '../types';
import TypingText from './TypingText';

interface AboutProps extends BaseProps {}

// Cast motion components to any to avoid TypeScript errors with missing props
const MotionDiv = motion.div as any;
const MotionButton = motion.button as any;

const notes = [
  {
    id: 1,
    image: "https://picsum.photos/id/1027/400/500", 
    title: "Your Smile",
    text: "Your smile lights up my darkest days. It's the first thing I want to see in the morning."
  },
  {
    id: 2,
    image: "https://picsum.photos/id/338/400/500", 
    title: "Your Kindness",
    text: "The way you care for others is inspiring. You have a heart of gold that makes everyone feel special."
  },
  {
    id: 3,
    image: "https://picsum.photos/id/331/400/500", 
    title: "Our Memories",
    text: "Every moment with you is a treasure I keep locked safely in my heart."
  },
  {
    id: 4,
    image: "https://picsum.photos/id/1011/400/500",
    title: "Your Strength",
    text: "You are stronger than you know. Watching you grow and overcome challenges makes me so proud."
  }
];

const About: React.FC<AboutProps> = ({ onNext }) => {
  const [activeIndex, setActiveIndex] = useState(0);

  const handleNext = () => {
    if (activeIndex < notes.length - 1) {
      setActiveIndex(activeIndex + 1);
    } else {
      setTimeout(onNext, 200);
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center py-6 md:py-10 px-4 min-h-[100dvh] bg-[#faf5f5] overflow-y-auto w-full">
      
      {/* Header Section */}
      <h2 className="text-3xl md:text-5xl font-handwriting text-rose-500 text-center z-20 mt-2 mb-6 flex-none">
        <TypingText text="Things I Love About You" speed={50} />
      </h2>

      {/* Cards Section - Flexible height that responds to screen size */}
      {/* Uses flex-1 to take available space but enforces a min-height for the cards */}
      <div className="relative w-full max-w-md h-[55vh] min-h-[400px] flex-none z-10 perspective-1000 mb-6">
        <AnimatePresence mode='popLayout'>
          {notes.map((note, index) => {
            if (index < activeIndex) return null; 

            const isFront = index === activeIndex;
            const offset = index - activeIndex;
            const scale = 1 - offset * 0.05;
            const yOffset = offset * 15; // Decreased offset for mobile compactness
            const zIndex = notes.length - offset;
            const opacity = 1 - offset * 0.2;

            return (
              <MotionDiv
                key={note.id}
                initial={{ opacity: 0, scale: 0.8, y: 100 }}
                animate={{ 
                    opacity: opacity,
                    scale: scale,
                    y: yOffset,
                    zIndex: zIndex,
                    rotate: isFront ? 0 : (index % 2 === 0 ? 2 : -2)
                }}
                exit={{ 
                    zIndex: 0,
                    scale: 0.8,
                    y: -50,
                    opacity: 0,
                    transition: { duration: 0.5 }
                }}
                transition={{ duration: 0.5, type: "spring" }}
                className="absolute top-0 left-0 right-0 mx-auto bg-white p-5 md:p-6 rounded-2xl shadow-2xl border border-stone-200 w-[90%] md:w-full h-full flex flex-col"
                style={{ transformOrigin: "top center" }}
              >
                <div className="flex-1 overflow-hidden rounded-lg mb-4 bg-stone-200 relative min-h-0">
                  <img 
                    src={note.image} 
                    alt={note.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl md:text-2xl font-bold text-rose-400 mb-2 font-handwriting shrink-0">
                    {isFront && <TypingText text={note.title} delay={300} speed={50} />}
                    {!isFront && note.title}
                </h3>
                <div className="text-stone-600 text-sm leading-relaxed font-medium min-h-[50px] shrink-0">
                    {isFront ? (
                        <TypingText text={note.text} delay={800} speed={30} />
                    ) : (
                        <span className="opacity-0">{note.text}</span>
                    )}
                </div>
                <div className="mt-4 flex justify-center text-yellow-400 gap-1 shrink-0">
                  {[...Array(3)].map((_, i) => (
                      <MotionDiv
                        key={i}
                        initial={{ scale: 0 }}
                        animate={isFront ? { scale: 1 } : { scale: 0 }}
                        transition={{ delay: 1.5 + (i * 0.2) }}
                      >
                          <Star size={16} fill="currentColor" />
                      </MotionDiv>
                  ))}
                </div>
              </MotionDiv>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Button Section - distinct margin-top to ensure separation */}
      <div className="flex items-center justify-center z-20 flex-none pb-8">
        <MotionButton
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleNext}
            className="bg-rose-500 text-white px-8 py-3 rounded-full font-semibold shadow-lg flex items-center gap-2"
        >
            {activeIndex < notes.length - 1 ? "Next Note" : "Continue"}
            <ArrowRight size={20} />
        </MotionButton>
      </div>
    </div>
  );
};

export default About;